enum class OS {
    ANDROID
}